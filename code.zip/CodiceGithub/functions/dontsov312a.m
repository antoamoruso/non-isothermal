function [fval] = dontsov312a(Kh, Ch, alp, th, g)
% Prima equazione del sistema 3.12 in Dontsov, espressa nella forma fval=0
% Kh ecc. qui sono grandezze scalari, NON vettoriali!
fg=fcn_g_del(g*Kh,Ch);
fval=Kh^6-alp^(1/2)/th^(1/2)*Ch^(3)*fg;
end
