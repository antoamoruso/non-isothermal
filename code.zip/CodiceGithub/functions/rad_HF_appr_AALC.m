% Modified from rad_HF_appr.m by Dontsov

function [Om,gamma,eff,del,lam,alp] = rad_HF_appr_AALC(tau,phi,g0)
%Note that lh is the scaled radius
phi(phi<1e-30)=1e-30;
th=tau*(2^6*phi^(3/2));
Qh=8/pi*phi;

%initial guess (for viscous regime)
alp=0*th+4/9;
Kh0=0*th+1/2;
Ch0=0*th+1/2;
g  =0*th+g0;

% g iteration
% for ig=1:50

%alpha iteration 
%ialpmax = 6; % small R and dT
ialpmax = 20; % large R and dT
for ialp=1:ialpmax
%fprintf(stdout,"ialp=%d\n",ialp);
    
Res=1;
ittmax=100;
itt=0;
tol=1e-5;

while (itt<ittmax)&&(Res>tol)

    if (itt==ittmax-1)&&(ialp==ialpmax)
       disp('No convergence, wl_radHF_appr'); 
       disp(Res);
    end
    itt=itt+1;
    Kh=Kh0;
    Ch=Ch0;
    
%    dKh=1e-5; % Dontsov's value
    dKh=1e-8;
 
    ittK=0;
    ResK=1;
    while (ittK<ittmax)&&(ResK>tol)
        ittK=ittK+1;
% Newton's method (modified from Dontosv)
        fg=fcn_g_del(g.*Kh,Ch);
        fgK=(fcn_g_del(g.*(Kh+dKh),Ch)-fg)/dKh;
        
        f1=Kh.^6-alp.^(1/2)./th.^(1/2).*Ch.^(3).*fg;
        f1K=6*Kh.^5-alp.^(1/2)./th.^(1/2).*Ch.^(3).*fgK;

        Kh=0.0*Kh+1.0*(Kh-f1./f1K);
        Kh(Kh<0)=1e-5; % valore usato da Dontsov
        Kh(Kh>1)=1-1e-5; % valore usato da Dontsov
        ResK=max(abs(f1./f1K));
    end

    ittC=0;
    ResC=1;
    while (ittC<ittmax)&&(ResC>tol)
       ittC=ittC+1;
% bisection method
       Chtest=Ch;
       for iCh=1:length(Ch)
         Ch(iCh) = fval_bisection("dontsov312b", 0, 0.0, 20.0, 40, 1e-5, Kh(iCh), alp(iCh), th(iCh), Qh);
       end
       ResC=max(abs(Ch-Chtest));
    end

    Res=max(((Kh-Kh0).^2+(Ch-Ch0).^2).^(1/2));
    Kh0=Kh;
    Ch0=Ch;
end

%sh=fcn_g_del(Kh,Ch);
sh=fcn_g_del(g.*Kh,Ch);

%calculate length
lh=Ch.^4.*sh.^2./Kh.^(10);

%update alpha
alp=0*lh;
alp(2:end)=(log(lh(2:end))-log(lh(1:end-1)))./(log(th(2:end))-log(th(1:end-1)));
alp(1)=alp(2);


g = 1 - (th./lh./alp).^(1/2);

g(g<=0) = 0;

end

p=0.0;%parameter for delta calculations
del=(1+fcn_Delta_p(g.*Kh,Ch,p))/2;  % delta segnato nell'articolo

%efficiency
eff=1-Ch.*alp.^(3/2).*beta(2*alp,3/2)./fcn_B_rad(g.*Kh,Ch,alp);

%width at the wellbore
lam=fcn_lam_rad(g.*Kh,Ch,alp);
wha=Ch.^2.*sh./Kh.^6./2.^(lam); % wha qui e' quella dell'articolo (eq. 3.9) divisa per 2.^(lam)

%converting to original scaling (eq. 5.3 di Dontsov RSOS 2016; Rh qui e' indicato con lh)
gamma=lh/(2^4*phi);  
Om=wha/(2^2*phi^(1/2)); % Om qui e' Omega dell'articolo (eq. 5.3) divisa per (1-rho)^(delta_segnato)*(1+rho).^(lambda)

end


