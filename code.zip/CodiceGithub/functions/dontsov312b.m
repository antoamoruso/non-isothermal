function [fval] = dontsov312b(Ch, Kh, alp, th, Qh)
% Seconda equazione del sistema 3.12 in Dontsov, espressa nella forma fval=0
% Kh ecc. qui sono grandezze scalari, NON vettoriali!
fB  =fcn_B_rad(Kh,Ch,alp);
fval=Ch^5-th^(3/2)*Kh^4/alp^(5/2)/Qh*fB;
end
