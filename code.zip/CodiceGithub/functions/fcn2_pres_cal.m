function p=fcn2_pres_cal(Cp, t, rho, alp)

w=2*Cp*sqrt(t)*(1-rho.^(1/alp)).^(1/2);

ds=rho(2)-rho(1);

[Rho,S]=meshgrid(rho,rho);

M = fcn_M_rad(Rho,S+ds/2)-fcn_M_rad(Rho,S-ds/2);   

p=M'*w/(2*pi);

%p(end)=2*p(end-1)-p(end-2);

end
