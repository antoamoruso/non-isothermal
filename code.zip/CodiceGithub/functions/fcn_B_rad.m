function B = fcn_B_rad(Kh,Ch,alp)

p=0.0;%parameter for delta calculation

del=(1+fcn_Delta_p(Kh,Ch,p))/2;
%del<0 or complex, controllo aggiunto da LC
%idel=find((del<0)|(abs(imag(del))>0));
%if isempty(idel)==0
%   disp('Warning: del is negative or complex in fcn_B_rad');
%   [del' Kh' Ch']
%end
%del(idel)=0;
%fine controllo aggiunto da LC

lam=fcn_lam_rad(Kh,Ch,alp);
%lam<0 or complex, controllo aggiunto da LC
%ilam=find((lam<0)|(abs(imag(lam))>0));
%if isempty(ilam)==0
%   disp('Warning: lam is negative or complex in fcn_B_rad');
%   lam
%end
%lam(ilam)=0;
%fine controllo aggiunto da LC

B0=@(x,p1,p2) beta(p1,p2).*(1-betainc(x,p1,p2));

B=2.^(1+del).*(-B0(1/2,lam+1,2+del)+B0(1/2,lam+2,1+del))+Ch.*alp.^(3/2).*beta(2*alp,3/2);

end

