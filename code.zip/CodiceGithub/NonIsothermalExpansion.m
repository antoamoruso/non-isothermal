% Non-isothermal sill expansion code.
% Modified from the Matlab code to produce closed form solutions
% for radial and KGD hydraulic fractures by E. V. Dontsov, which
% is available from the Dryad Digital Repository
% at http://dx.doi.org/10.5061/dryad.gh469.
clear all;
close all;

%add folder to path
addpath('functions');

%graphics_toolkit ("gnuplot");
%graphics_toolkit ("fltk");
%graphics_toolkit ("qt");

%do not set zero values to any of the parameters, put a a very small value instead
%material parameters
% valori numerici
Q0 = 0.5;  % m^3/s  (1982-1984: 0.5; 2011-2013: 0.05)
E = 3.75e10; % Pa  modulo di Young di riferimento
nu = 0.25;  % rapporto di Poisson
K = 1e6; % Pa m^(1/2)   resistenza alla frattura
mu = [1e3 1e4 1e5 1e6]; % viscosita' magma, Pa s
g0 = 0.6955;

diff = 1e-6;  % diffusivita' termica, m2/s
CalSpec = 1200; % calore specifico, J/kg/K
Lm = 4.5e5; % calore latente, J/kg
Ts = 750;
Tr = 740;  % dT=10K
lambda = fval_bisection("dT_lambda", 0, 0.000001, 0.8, 1000, 1e-6, Ts-Tr, CalSpec, Lm);

Kp = 4 * sqrt(2/pi) .* K;
Ep = E/(1-nu^2);
mup = 12 * mu;

Cp = 2 * lambda * sqrt(diff);

H=1;%m Q=Q0/H for KGD

%number of points
N=1000;

for im = 1:length(mu)
%evaluation time (sec)
%tmax=2e7*(log10(mu(im))/log10(mu(1)))^1.5;
tmax=2e6*(log10(mu(im))/log10(mu(1)))^1.5;
nt = tmax/2e4;
t = linspace(10000, tmax, nt);
R = zeros(size(t));
alpR = zeros(size(t));

for it = 1:length(t)
%global solution

plotfig = 0;
[R(it),w,p,rho,eta,alp]=get_rad_sol_AALC(Ep,mup(im),Kp,Cp,Q0,t(it),N,plotfig);
alpR(it) = alp(end);
% Calcolo di w_sol, spessore della parte solida
pot = 1/alp(end);
w_sol = (2*Cp) .* t(it)^(1/2) .* (1-rho.^(pot)).^(1/2);
end % endfor it

% Evoluzione per la M-solution
RM = 0.6955 * Ep^(1/9) * Q0^(1/3) * t.^(4/9) / mup(im)^(1/9);

filename = sprintf('Rt_solidificazione_dT%g_visc%.0e_K%.0e.dat', Ts-Tr, mu(im), K);
fp = fopen(filename,'w');
fprintf(fp,'# Fracture toughness %g Pa m^(1/2)\n', K);
fprintf(fp,'# dT %g K\n', Ts-Tr);
fprintf(fp,'# Viscosity %g Pa s\n', mu(im));
fprintf(fp,'# RM is the M-solution by Savitski and Detournay (2002)\n');
fprintf(fp,'# t(s)    R(m)     RM(m)    alpha\n');
fprintf(fp,'%8.0f %10.5f %10.5f %7.5f\n', [t; R; RM; alpR]);
fclose(fp);

end %endfor im

quit
exit
