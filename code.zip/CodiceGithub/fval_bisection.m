
% modified from function bisection.m in the Numerical Methods Library for OCTAVE 
% (Carlos Balsa, http://www.ipb.pt/~balsa/)

function [x, res, nbit] = fval_bisection(f, fval, a, b, itmax, tol, varargin)
%
% BISECTION Find function argument, given function value.
%
% X = FVAL_BISECTION(FUN,FVAL,A,B,ITMAX,TOL) tries to find an argument X of the continuous
% function FUN in the interval [A, B] for which FUN(X)=FVAL using the bisection method. FUN accepts
% real scalar input x and returns a real scalar value. If the search fails an
% error message is displayed. FUN can also be an inline object.
%
% [X, RES, NBIT] = BISECTION(FUN,FVAL,A,B,ITMAX,TOL) returns the value of the
% residual in X solution and the iteration number at which the solution was
% computed.
%
% Parameters
% FUN   evaluated function.
% FVAL  function value
% A,B   [A,B] interval where the solution is computed, A < B and
%       sign(FUN(A)) = - sign(FUN(B)).
% ITMAX maximal number of iterations.
% TOL   tolerance on the stopping criterion.
%
% Returns
% X     computed solution.
% NBIT  number of iterations to find the solution.
% RES   value of the residual in X solution.
%

nbit = 0;
fa = feval(f,a,varargin{:})-fval;
fb = feval(f,b,varargin{:})-fval;
fc = 1;

if fa*fb > 0
  error("You have to choose a,b / sign(f(a)) = -sign(f(b)).");
elseif fa == 0
  x = a ; res = 0 ; nbit = 0;
  return
elseif fb == 0
  x = b ; res = 0 ; nbit = 0;
  return
end

while abs(b-a) > tol && nbit <= itmax
  c = a+(b-a)/2;
  fc = feval(f,c,varargin{:})-fval;

  if fa*fc<0
      b = c;
      fb = fc;
    else
      a = c;
      fa = fc;
  end
  nbit = nbit+1;
end
if nbit > itmax
  fprintf(["bisection stopped without converging to the desired tolerance",...
  "because the maximum number of iteration was reached.\n"]);
end
x = c;
res = fc;
end
