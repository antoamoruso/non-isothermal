function x = dT_lambda(lambda, deltaT, Cp, Lm)
  x = Lm / Cp * sqrt(pi) * lambda .* exp(lambda.*lambda) .* erfc(-lambda) - deltaT;
end
